var { spawn, exec } = require("child_process");
const glob = require("glob");
const shelljs = require("shelljs");
const parser = require("bookmark-parser");
const { stderr } = require("process");

const home = require("os").homedir();

module.exports = {
  start: (url, res) => {
    // Use spawn for a new firefox window
    var proc = spawn("firefox", ["--new-window", url]);
    if (proc.error == null) {
      res
        .status(200)
        .json({ message: `Started firefox successfully with ${url}` });
    } else {
      res.status(200).json({ error: `Error starting firefox` });
    }
  },

  stop: (res) => {
    // Sending SIGTERM to processes named firefox
    var proc = exec('ps -e | grep "firefox"', (error, stdout, stderr) => {
      if (error == null) {
        exec("pkill -15 firefox");
        res.status(200).json({ message: `Stopped firefox successfully` });
      } else {
        res.status(200).json({ error: `Firefox instance not running` });
      }
    });

    // var proc = exec("pkill -15 firefox", (error, stdout, stderr) => {
    //   if (error == null) {
    //     res.status(200).json({ message: `Stopped firefox successfully` });
    //   } else {
    //     res.status(200).json({ error: `Firefox instance not running` });
    //   }
    // });
  },

  geturl: (res) => {
    glob(
      `${home}/.mozilla/firefox/**.default**/sessionstore-backups/recovery.jsonlz4`,
      (err, files) => {
        if (err) throw err;
        if (files.length == 0) {
          res.status(200).send("No active tabs running");
        } else if (files[0]) {
          parser
            .readFromJSONLZ4File(files[0])
            .then((result) => {
              //   for (i = 0; i < result.windows.length; i++) {
              //     last_window = result.windows[i];
              //     last_tab = last_window["tabs"];
              //     console.log(last_tab[0].entries);
              //   }
              last_window = result.windows[result.windows.length - 1]; // Get last window
              last_tab = last_window["tabs"]; // Get all tabs of last windows
              last_tab_entries = last_tab[last_tab.length - 1].entries; // Get last tab of last window
              //   console.log(last_tab_entries[last_tab_entries.length-1].url);
              res.status(200).json({
                last_active: last_tab_entries[last_tab_entries.length - 1].url,
              });
            })
            .catch((err) => {
              res.send(err);
            });
        }
      }
    );
  },

  cleanup: (res) => {
    var datetime = new Date();
    var backupLoc = `${home}/FirefoxBackup/${datetime}`;
    exec(`mkdir -p ${backupLoc}`); // Create backup loc

    glob(`${home}/.mozilla/firefox/**.default*/`, (error, files) => {
      //Find the default folder
      if (error) throw error;
      try {
        for (i = 0; i < files.length; i++) {
          // Loop through the folders having default in name
          var stat = shelljs.cp("-r", files[i], backupLoc); // Copy contents to the backup location
          if (stat.code === 0) {
            // If backup is successful
            glob(`${files[i]}**.sqlite*`, (error, sqlite_files) => {
              if (error) throw error;
              for (j = 0; j < sqlite_files.length; j++) {
                var rem = shelljs.rm("-rf", sqlite_files[j]); // Remove the sqlite files
              }
            });
            shelljs.rm("-rf", `${files[i]}/bookmarkbackups`);
            glob(
              `${files[i]}/sessionstore-backups/recovery*`,
              (error, rec_files) => {
                if (error) throw error;
                for (j = 0; j < rec_files.length; j++) {
                  var rem = shelljs.rm(rec_files[j]); // Remove the sqlite files
                }
              }
            );
          } else {
            throw " Backup unsuccesful";
          }
        }
        res.status(200).json({ message: "Cleanup of firefox successful" });
      } catch (err) {
        res.status(200).json({ error: err });
      }
    });
  },
};
