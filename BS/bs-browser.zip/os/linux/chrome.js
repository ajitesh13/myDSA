var { spawn, exec } = require("child_process");
const glob = require("glob");
const shelljs = require("shelljs");
const parser = require("bookmark-parser");
const { stderr } = require("process");

const home = require("os").homedir();
module.exports = {
  start: (url, res) => {
    var proc = spawn("google-chrome-stable", ["--new-window", url]);
    if (proc.error == null) {
      res.status(200).json({ message: `Started chrome successfully` });
    } else {
      res.status(200).json({ error: `Error starting chrome` });
    }
  },

  stop: (res) => {
    var proc = exec(
      "pkill -15 google-chrome-stable",
      (error, stdout, stderr) => {
        if (error == null) {
          res.status(200).json({ message: `Stopped chrome successfully` });
        } else {
          res.status(200).json({ error: `Chrome instance not running` });
        }
      }
    );
  },

  geturl: (res) => {
    // Read the latest tab file in `${home}/.config/google-chrome/Default/Sessions` - that file is in some unknown format
    // glob(`${home}/.config/google-chrome/Default/Sessions`, (err, files) => {
    // });
  },

  cleanup: (res) => {
    var datetime = new Date();
    var backupLoc = `${home}/ChromeBackup/${datetime}/Default`;
    exec(`mkdir -p ${backupLoc}`); // Create backup loc
    var proc = shelljs.cp(
      "r",
      `${home}/.config/google-chrome/Default`,
      backupLoc
    );
    if (proc.code == 0) {
      var rem = shelljs.rm("-rf", `${home}/.config/google-chrome/Default`);
      if (rem.code == 0) {
        res
          .status(200)
          .json({ message: "Cleaned chrome history successfully" });
      } else {
        res.status(200).json({ error: "Error removing chrome data" });
      }
    } else {
      res.status(200).json({ error: "Error backing up data" });
    }
  },
};
