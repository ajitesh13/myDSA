// TODO - need to check and run on windows

module.exports = {
  start: (url, res) => {},

  stop: (res) => {},

  geturl: (res) => {},

  cleanup: (res) => {},
};
