const {
  start,
  stop,
  cleanup,
  geturl,
} = require("../controllers/browserControl");

const route = (app) => {
  app.route("/start").get(start);
  app.route("/stop").get(stop);
  app.route("/cleanup").get(cleanup);
  app.route("/geturl").get(geturl);
};

module.exports = {
  route,
};
