const express = require("express");
const { route } = require("../router/route");
const app = express();

app.use(express.json());

route(app);

module.exports = app;
