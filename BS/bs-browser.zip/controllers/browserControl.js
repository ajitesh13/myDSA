var platform = true;
const firefoxLinux = require("../os/linux/firefox");
const chromeLinux = require("../os/linux/chrome");
const firefoxWindows = require("../os/windows/firefox");
const chromeWindows = require("../os/windows/chrome");

if (process.platform == "linux") {
  var firefox = firefoxLinux;
  var chrome = chromeLinux;
} else if (process.platform == "win32") {
  var firefox = firefoxWindows;
  var chrome = chromeWindows;
} else {
  platform = false;
}

module.exports = {
  start: (req, res) => {
    if (platform) {
      const browser = req.query.browser;
      const url = req.query.url || "google.com";
      if (browser === "firefox") {
        firefox.start(url, res);
      } else if (browser === "chrome") {
        chrome.start(url, res);
      } else res.send(`Invalid browsername - ${browser}`);
    } else {
      res.send("Platform not supported");
    }
  },

  stop: (req, res) => {
    if (platform) {
      const browser = req.query.browser;
      if (browser === "firefox") {
        firefox.stop(res);
      } else if (browser === "chrome") {
        chrome.start(res);
      } else res.stop(`Invalid browsername - ${browser}`);
    } else {
      res.send("Platform not supported");
    }
  },

  geturl: (req, res) => {
    if (platform) {
      const browser = req.query.browser;
      if (browser === "firefox") {
        firefox.geturl(res);
      } else if (browser === "chrome") {
        chrome.geturl(res);
      } else res.send(`Invalid browsername - ${browser}`);
    } else {
      res.send("Platform not supported");
    }
  },

  cleanup: (req, res) => {
    if (platform) {
      const browser = req.query.browser;
      if (browser === "firefox") {
        firefox.cleanup(res);
      } else if (browser === "chrome") {
        chrome.cleanup(res);
      } else res.send(`Invalid browsername - ${browser}`);
    } else {
      res.send("Platform not supported");
    }
  },
};
