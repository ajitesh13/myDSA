const app = require("./config/express");
require("dotenv").config();

const port = process.env.PORT || "8080";
const host = process.env.HOST || "localhost";

app.listen(port, host, () => {
  console.log(`Listening at ${host}:${port}`);
});
